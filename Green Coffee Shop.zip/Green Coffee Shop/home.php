<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/wishlist_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<div class="home-bg">

<section class="home">

   <div class="swiper home-slider">
   
   <div class="swiper-wrapper">

      <div class="swiper-slide slide">
         <div class="image">
            <img src="img/thumb1.jpg" alt="">
         </div>
         <div class="content">
            
            <h3>Welcome to the Green Coffee Shop</h3>
            
            <a href="shop.php" class="btn" >Shop now</a>
         </div>
      </div>

      <div class="swiper-slide slide">
         <div class="image">
            <img src="img/thumb2.jpg" alt="">
         </div>
         <div class="content">
            <span>upto 30% off</span>
            <h3>latest coffee</h3>
            <a href="shop.php" class="btn">shop now</a>
         </div>
      </div>
      

   </div>

      <div class="swiper-pagination"></div>

   </div>

</section>

</div>

 <!-- MENU -->
 <section class="menu" id="menu">
        <h1 class="heading">...<span></span></h1>

        <div class="box-container">
            <a href="#" class="box">
                <img src="img/thumb2.jpg" alt="">
                <div class="content">
                    <h3 style="color: #3C630B;">Green coffee</h3>
                    <p>It contains more chlorogenic acid than roasted coffee.</p>
                    <span>Read More</span>
                </div>
            </a>

            <a href="#" class="box">
                <img src="img/thumb.jpg" alt="">
                <div class="content">
                    <h3 style="color: #3C630B;">Natural selection</h3>
                    <p>It might affect blood vessels so that blood pressure is reduced.</p>
                    <span>Read More</span>
                </div>
            </a>

            <a href="#" class="box">
                <img src="img/thumb0.jpg" alt="">
                <div class="content">
                    <h3 style="color: #3C630B;">Green coffee</h3>
                    <p>It contains more chlorogenic acid than roasted coffee.</p>
                    <span>Read More</span>
                </div>
            </a>

            <a href="#" class="box">
                <img src="img/thumb1.jpg" alt="">
                <div class="content">
                    <h3 style="color: #3C630B;">Croisant</h3>
                    <p>Croissants are a style of viennoiserie pastries.</p>
                    <span>Read More</span>
                </div>
            </a>

            
        </div>
    </section>
 <!-- ABOUT -->
 <section class="about" id="about">
       
       <div class="row">
           <div class="image">
               <img src="img/about-us.jpg" alt="">
           </div>

           <div class="content">
               <img src="img/download.png" alt="">
               <h3 class="title">Healthy Coffee</h3>
               <p style="font-size: 30px;">Save up to 20% by ordering on our site</p>
               <a href="#" class="btn">read more</a>
               
           </div>
       </div>
   </section>

<section class="home-products">

   <h1 class="heading">Trending Products</h1>

   <div class="swiper products-slider">

   <div class="swiper-wrapper">

   <?php
     $select_products = $conn->prepare("SELECT * FROM `products` LIMIT 6"); 
     $select_products->execute();
     if($select_products->rowCount() > 0){
      while($fetch_product = $select_products->fetch(PDO::FETCH_ASSOC)){
   ?>
   <form action="" method="post" class="swiper-slide slide">
      <input type="hidden" name="pid" value="<?= $fetch_product['id']; ?>">
      <input type="hidden" name="name" value="<?= $fetch_product['name']; ?>">
      <input type="hidden" name="price" value="<?= $fetch_product['price']; ?>">
      <input type="hidden" name="image" value="<?= $fetch_product['image_01']; ?>">
      <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button>
      <a href="quick_view.php?pid=<?= $fetch_product['id']; ?>" class="fas fa-eye"></a>
      <img src="uploaded_img/<?= $fetch_product['image_01']; ?>" alt="">
      <div class="name"><?= $fetch_product['name']; ?></div>
      <div class="flex">
         <div class="price"><span></span><?= $fetch_product['price']; ?><span>/FCFA</span></div>
         <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
      </div>
      <input type="submit" value="add to cart" class="btn" name="add_to_cart">
   </form>
   <?php
      }
   }else{
      echo '<p class="empty">no products added yet!</p>';
   }
   ?>

   </div>

   <div class="swiper-pagination"></div>

   </div>

</section>
<!--two slide-->
<section class="slide" id="delivery">

<div class="row">
    

    <div class="content">
        
        <div class="icons-container">
            <div class="icons">
                
                <img src="img/6.jpg" alt="">
                
            </div>
            <div class="icons">
                <img src="img/7.jpg" alt="">
                
            </div>
           
        </div>
    </div>
</div>
</section>

 <!-- delivery -->
 <section class="delivery" id="delivery">

<div class="row">
    

    <div class="content">
        
        <div class="icons-container">
            <div class="icons">
                <img src="img/icon2.png" alt="">
                <h3 style="color: #3C630B;">Great savings</h3>
                <p>saving big on Orders</p>
            </div>
            <div class="icons">
                <img src="img/icon1.png" alt="">
                <h3 style="color: #3C630B;">24/7 support</h3>
                <p>one-on-one support</p>
            </div>
            <div class="icons">
                <img src="img/icon0.png" alt="">
                <h3 style="color: #3C630B;">Gift Voucher</h3>
                <p>Gift to someone</p>
            </div>
            <div class="icons">
                <img src="img/icon.png" alt="">
                <h3 style="color: #3C630B;">Delivery</h3>
                <p>Home delivery</p>
            </div>
        </div>
    </div>
</div>
</section>

<section class="brand" id="brand">

        <div class="row">
            

            <div class="content">
                
                <div class="icons-container">
                    <div class="icons">
                        <img src="img/brand (1).jpg" alt="">
                       
                    </div>
                    <div class="icons">
                        <img src="img/brand (2).jpg" alt="">
                       
                    </div>
                    <div class="icons">
                        <img src="img/brand (3).jpg" alt="">
                       
                    </div>
                    <div class="icons">
                        <img src="img/brand (4).jpg" alt="">
                       
                    </div>
                    <div class="icons">
                        <img src="img/brand (5).jpg" alt="">
                       
                    </div>
                </div>
            </div>
        </div>
    </section>








<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".home-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
    },
});

 var swiper = new Swiper(".category-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
         slidesPerView: 2,
       },
      650: {
        slidesPerView: 3,
      },
      768: {
        slidesPerView: 4,
      },
      1024: {
        slidesPerView: 5,
      },
   },
});

var swiper = new Swiper(".products-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      550: {
        slidesPerView: 2,
      },
      768: {
        slidesPerView: 2,
      },
      1024: {
        slidesPerView: 3,
      },
   },
});

</script>

</body>
</html>